<template>
  <image class="weapp-svg-load-scoped" :src="base64Svg" />
</template>

<script setup lang="ts">
const props = withDefaults(defineProps<Props>(), {
  color: '',
});

interface Props {
  name: string | null;
  color?: string;
}

// eslint-disable-next-line @typescript-eslint/no-var-requires
const svgModule = require(`../assets/icons/${props.name}.svg`);
const base64Svg = ref();
console.log(typeof (svgModule))
base64Svg.value = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgModule)}`;
console.log(base64Svg.value);
// base64Svg.value =
//   'data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20viewBox%3D%2224%2024%2048%2048%22%3E%3CanimateTransform%20attributeName%3D%22transform%22%20type%3D%22rotate%22%20repeatCount%3D%22indefinite%22%20from%3D%220%22%20to%3D%22360%22%20dur%3D%221400ms%22%3E%3C%2FanimateTransform%3E%3Ccircle%20cx%3D%2248%22%20cy%3D%2248%22%20r%3D%2220%22%20fill%3D%22none%22%20stroke%3D%22%233666%22%20stroke-width%3D%222%22%20transform%3D%22translate%5C(0%2C0%5C)%22%3E%3Canimate%20attributeName%3D%22stroke-dasharray%22%20values%3D%221px%2C%20200px%3B100px%2C%20200px%3B100px%2C%20200px%22%20dur%3D%221400ms%22%20repeatCount%3D%22indefinite%22%3E%3C%2Fanimate%3E%3Canimate%20attributeName%3D%22stroke-dashoffset%22%20values%3D%220px%3B-15px%3B-125px%22%20dur%3D%221400ms%22%20repeatCount%3D%22indefinite%22%3E%3C%2Fanimate%3E%3C%2Fcircle%3E%3C%2Fsvg%3E';
</script>

<style lang="less">
.weapp-svg-load-scoped {
  flex-shrink: 0;
  position: relative;
  width: 40px;
  height: 40px;
  vertical-align: -2px;
  fill: currentcolor;
}
</style>
