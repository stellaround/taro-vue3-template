<template>
  <svg v-if="!isWeapp" class="svg-icon-scoped" aria-hidden="true" @mouseover="activeColor" @mouseout="deActiveColor">
    <use :href="iconName" />
  </svg>
  <Suspense v-else>
    <template #default>
      <weapp-load-svg :color="props.color" :name="props.name"></weapp-load-svg>
    </template>
    <template #fallback> <view></view> </template>
  </Suspense>
</template>

<script setup lang="ts">
import WeappLoadSvg from './weapp-load-svg.vue';

const props = withDefaults(defineProps<Props>(), {
  color: '',
  size: '20px',
});

interface Props {
  name: string | null;
  color?: string;
  hoverColor?: string;
  notPointer?: boolean;
  size?: string;
}

const iconName = ref(`#icon-${props.name}`);
const needPointer = ref(props.notPointer ? 'none' : 'pointer');
const iconSize = ref(props.size);

const currentColor = ref();
const originalColor = props.color;
currentColor.value = props.color;
const activeColor = () => {
  currentColor.value = props.hoverColor;
};
const deActiveColor = () => {
  currentColor.value = originalColor;
};

const isWeapp = process.env.TARO_ENV === 'weapp';
if (!isWeapp) {
  import(`@/assets/icons/${props.name}.svg`);
}
</script>

<style lang="less">
.svg-icon-scoped {
  flex-shrink: 0;
  position: relative;
  width: v-bind(iconSize);
  height: v-bind(iconSize);
  vertical-align: -2px;
  color: v-bind(currentColor);
  cursor: v-bind(needPointer);
}
</style>
