<script setup lang="ts"></script>

<template>
  <view>这是index页面</view>
</template>

<style scoped lang="less"></style>
